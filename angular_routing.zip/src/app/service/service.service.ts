import { Injectable } from '@angular/core';
import { AngularFireAuth} from '@angular/fire/auth';
import {AngularFirestore,AngularFirestoreModule} from '@angular/fire/firestore'

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
isLoggedIn = false
  constructor(
    public firebaseAuth : AngularFireAuth,
    public fireservice: AngularFirestore
  ) { }
   signInDetails(data:any){
    return this.fireservice.collection('signup').add(data)
   }
}
