import { LifecycleHooks } from '@angular/compiler/src/lifecycle_reflector';
import { Component, ViewChild } from '@angular/core';
import {Router} from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'loginFirebase';
  constructor(
   private Router: Router) { }

  ngOnInit() {
   
  }
  redirectToAboutUs(){
    this.Router.navigate(['/about-us'])
  }
}
