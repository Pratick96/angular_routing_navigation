import { NgModule, ViewChild } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AboutUsComponent} from '../app/view/about-us/about-us.component'
import {ContactUsComponent} from '../app/view/contact-us/contact-us.component'
import {HomeComponent} from '../app/view/home/home.component'
import {ErrorCComponent} from '../app/view/error-c/error-c.component'




const routes: Routes = [
  {
   path: '',
   redirectTo: 'home',
   pathMatch: 'full'
  },
  {
    path: 'home',
    component:HomeComponent
  },
  {
    path: 'contact-us',
    component:ContactUsComponent
  },
  {
    path: 'about-us',
    component:AboutUsComponent
  },
  {
    path: '**',
    component:ErrorCComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {

 }
