import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-error-c',
  templateUrl: './error-c.component.html',
  styleUrls: ['./error-c.component.scss']
})
export class ErrorCComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
